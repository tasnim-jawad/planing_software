export default [
    {
        name: "full_name",
        label: "Full Name",
        type: "text",
        value: "",
    },

    {
        name: "email",
        label: "Email",
        type: "email",
        value: "",
    },
    // {
    //     name: "user_role",
    //     label: "User Role",
    //     type: "select",
    //     value: "",
    // },

    {
        name: "password",
        label: "Password",
        type: "password",
        value: "",
    },
    {
        name: "password_confirmation",
        label: "Password Confirmation",
        type: "password",
        value: "",
    },

];
