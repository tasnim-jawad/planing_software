<?php

namespace App\Models\Admin\BarshikPorikolpona;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BarshikPorikolpona extends Model
{
    use HasFactory;
    protected $guarded = [];
}
