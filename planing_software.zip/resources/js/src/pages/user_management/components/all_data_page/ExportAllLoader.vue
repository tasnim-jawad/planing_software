<template lang="">
    <div class="loader export_loader">
        <div class="loader_body">
            <div class="progress"></div>
            <div class="load_amount">
                <h4>0</h4>
                <h5>%</h5>
            </div>
        </div>
    </div>
</template>
<script>
export default {

}
</script>
<style lang="">

</style>
