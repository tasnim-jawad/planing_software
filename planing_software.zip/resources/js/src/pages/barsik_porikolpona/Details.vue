<template >
    <div>
        details
        a
    </div>
</template>
<script>
export default {

}
</script>
<style lang="">

</style>
