<template>
    <div>
        Dashboard
        <a href=""></a>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped></style>
